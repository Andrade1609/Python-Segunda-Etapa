Windows PowerShell    Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `oft Corporation. Todos os direitos reservados.
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Triple T","autor":"Tung Sahur da Silva","ano":1867}'


ano          : 1867
autor        : Tung Sahur da Silva
data_criacao : 2026-07-29 08:57:51.927675
id           : 4
titulo       : Triple T



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Wadanohara And The Great Blue Sea","autor":"Funamusea","ano":2018'
Invoke-RestMethod :
400 Bad Request
Bad Request
Failed to decode JSON object: Expecting &#39;,&#39; delimiter: line 1 column 77 (char 76)
No linha:1 caractere:1
+ Invoke-RestMethod http://127.0.0.1:5000/api/livros `
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : InvalidOperation: (System.Net.HttpWebRequest:HttpWebRequest) [Invoke-RestMethod], WebException
    + FullyQualifiedErrorId : WebCmdletWebResponseException,Microsoft.PowerShell.Commands.InvokeRestMethodCommand
PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Wadanohara And The Great Blue Sea","autor":"Funamusea","ano":2018}'


ano          : 2018
autor        : Funamusea
data_criacao : 2026-07-29 09:01:29.097620
id           : 5
titulo       : Wadanohara And The Great Blue Sea



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Obsolete Dream","autor":"Funamusea","ano":2014'
Invoke-RestMethod :
400 Bad Request
Bad Request
Failed to decode JSON object: Expecting &#39;,&#39; delimiter: line 1 column 58 (char 57)
No linha:1 caractere:1
+ Invoke-RestMethod http://127.0.0.1:5000/api/livros `
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : InvalidOperation: (System.Net.HttpWebRequest:HttpWebRequest) [Invoke-RestMethod], WebException
    + FullyQualifiedErrorId : WebCmdletWebResponseException,Microsoft.PowerShell.Commands.InvokeRestMethodCommand
PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Obsolete Dream","autor":"Funamusea","ano":2014}'


ano          : 2014
autor        : Funamusea
data_criacao : 2026-07-29 09:03:43.690296
id           : 6
titulo       : Obsolete Dream



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Seaside Dispatches","autor":"Funamusea","ano":2017}'


ano          : 2017
autor        : Funamusea
data_criacao : 2026-07-29 09:07:51.589603
id           : 7
titulo       : Seaside Dispatches



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Europa Medieval","autor":"Donald Matthew","ano":2006}'


ano          : 2006
autor        : Donald Matthew
data_criacao : 2026-07-29 09:11:38.656104
id           : 8
titulo       : Europa Medieval



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Space Atlas: Mapping The Universe And Beyond","autor":"James Trefil","ano":2012}'


ano          : 2012
autor        : James Trefil
data_criacao : 2026-07-29 09:14:26.178958
id           : 9
titulo       : Space Atlas: Mapping The Universe And Beyond



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"The Summer Hikaru Died","autor":"Mio Nukaga","ano":2021}'


ano          : 2021
autor        : Mio Nukaga
data_criacao : 2026-07-29 09:17:17.648762
id           : 10
titulo       : The Summer Hikaru Died



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Jojos Bizarre Adventure","autor":"Hirohiko Araki","ano":1987}'


ano          : 1987
autor        : Hirohiko Araki
data_criacao : 2026-07-29 09:18:28.338853
id           : 11
titulo       : Jojos Bizarre Adventure



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Stell Ball Run","autor":"Hirohiko Araki","ano":2004}'


ano          : 2004
autor        : Hirohiko Araki
data_criacao : 2026-07-29 09:19:50.209325
id           : 12
titulo       : Stell Ball Run



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros `
>>    -Method POST `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Alice Adventures in Wonderland","autor":"Lewis Carroll","ano":1865}'


ano          : 1865
autor        : Lewis Carroll
data_criacao : 2026-07-29 09:22:03.390592
id           : 13
titulo       : Alice Adventures in Wonderland



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros/1 `
>>    -Method PUT `
>>    -ContentType "application/json" `
>>    -Body '{"titulo":"Cotemig","autor":"3A1","ano":2026}'


ano          : 2026
autor        : 3A1
data_criacao : 2026-07-29 08:51:25.922474
id           : 1
titulo       : Cotemig



PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros/5 -Method DELETE

PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros/6 -Method DELETE

PS C:\Users\12401307> Invoke-RestMethod http://127.0.0.1:5000/api/livros/7 -Method DELETE