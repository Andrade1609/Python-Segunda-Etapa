import math as m

def raiz(a):
    return m.sqrt(a)