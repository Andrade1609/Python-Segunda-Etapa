import math
from soma import somar
from subtrair import subtracao 
from multiplicar import multiplicacao 
from divisao import dividir 
from potencia import potenciacao
from raizquadrada import raiz
from cambio import cotacao_dolar

def calculadora():
    a = float(input("Digite um numero: "))
    operacao = int(input("Escolha uma operacao (somar[1], subtrair[2], multiplicar[3], dividir[4], potencia[5], raiz quadrada[6] ou cotação em dolar[7]):"))

    if operacao == 1:
        b = float(input("Digite mais outro numero: "))
        print(f"resultado: {somar(a, b)}")
    elif operacao == 2:
        b = float(input("Digite mais outro numero: "))
        print(f"resultado: {subtracao(a, b)}")
    elif operacao == 3:
        b = float(input("Digite mais outro numero: "))
        print(f"resultado: {multiplicacao(a, b)}")
    elif operacao == 4:
        b = float(input("Digite mais outro numero: "))
        print(f"resultado: {dividir(a, b)}")
    elif operacao == 5:
        b = float(input("Digite mais outro numero: "))
        print(f"resultado: {potenciacao(a, b)}")
    elif operacao == 6:
        print(f"resultado: {raiz(a)}")
    elif operacao == 7:
        valor_dolar = a / float(cotacao_dolar())
        print(f"resultado: {round(valor_dolar, 2)}")
    else:
        print("Operação invalida!")
print