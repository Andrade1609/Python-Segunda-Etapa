from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return '''
          <!DOCTYPE html>
          <html lang= "pt-BR"
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Currículo</title>
          </head>
          <body>
               <h1><strong>- - Currículo - -</strong></h1>

               <h2>Informações Pessoais</h2>
               <ul>
                   <li><strong>Nome:</strong> Artur Andrade</li>
                   <li><strong>Idade:</strong> 17</li>
                   <li><strong>Email:</strong> arturandrade.a.c@gmail.com</li>
                </ul>

                <h2>Experiencia Profissional</h2>
                <ul>
                   <li><strong>Empresa:</strong> LLG engenharia</li>
                   <li><strong>Cargo:</strong> Principiante</li>
                   <li><strong>Período:</strong> 2022-2023</li>
                </ul>

                <h2>Idiomas</h2>
                <ul>
                   <li><strong>Inglês:</strong> Avançado</li>
                   <li><strong>Sueco:</strong> Iniciante</li>
                </ul>
          </body>
          </html>
    '''

if __name__ == '__main__':
    app.run(debug=True)