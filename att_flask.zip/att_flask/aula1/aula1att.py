from flask import Flask

app = Flask(__name__)

@app.route("/decorator")
def decorator():
    return "Um decorator em Python é uma função que permite modificar ou estender o comportamento de outra função ou método sem alterar seu código original."

@app.route("/")
def hello_world():
    return "Hello world."

if __name__ == '__main__':
    app.run(debug=True)